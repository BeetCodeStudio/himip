<?php get_header(); ?>

    <!-- Main Content -->
    <div class="bg-blue-50 text-center py-20">
        <h2 class="title capitalize py-3">Struktur Organisasi</h2>
    </div>
    <!-- struktur himip -->
    <div class="container mx-auto py-10 flex flex-col space-y-5">
        <!-- <h2 class="title text-center tracking-wide">Struktur Organisasi</h2> -->
        <!-- <h2 class="text-3xl font-bold w-full text-center tracking-wide">Struktur Organisasi</h2> -->
        <section class="text-gray-600 body-font">
            <div class="container">
                <div class="title-container">
                    <h1 class="title2">BPH Inti</h1>
                    <p class="petunjuk">Penjelasan Lorem ipsum dolor sit amet
                        consectetur adipisicing elit. Quae, asperiores?</p>
                </div>
                <div class="flex flex-wrap -m-4">
                    <div class="p-4 lg:w-1/2">
                        <div
                            class="h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left">
                            <img alt="team"
                                class="flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"
                                src="https://source.unsplash.com/random/8">
                            <div class="flex-grow sm:pl-8">
                                <h2 class="title-font font-medium text-lg text-gray-900">Holden Caulfield</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/2">
                        <div
                            class="h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left">
                            <img alt="team"
                                class="flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"
                                src="https://source.unsplash.com/random/7">
                            <div class="flex-grow sm:pl-8">
                                <h2 class="title-font font-medium text-lg text-gray-900">Alper Kamu</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/2">
                        <div
                            class="h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left">
                            <img alt="team"
                                class="flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"
                                src="https://source.unsplash.com/random/6">
                            <div class="flex-grow sm:pl-8">
                                <h2 class="title-font font-medium text-lg text-gray-900">Atticus Finch</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/2">
                        <div
                            class="h-full flex sm:flex-row flex-col items-center sm:justify-start justify-center text-center sm:text-left">
                            <img alt="team"
                                class="flex-shrink-0 rounded-lg w-48 h-48 object-cover object-center sm:mb-0 mb-4"
                                src="https://source.unsplash.com/random/5">
                            <div class="flex-grow sm:pl-8">
                                <h2 class="title-font font-medium text-lg text-gray-900">Henry Letham</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="text-gray-600 body-font">
            <div class="container px-5 py-10 mx-auto">
                <div class="flex flex-col text-center w-full mb-20">
                    <h1 class="text-2xl font-medium title-font mb-4 text-gray-900">Dinas Kaderisasi</h1>
                    <p class="lg:w-2/3 mx-auto leading-relaxed text-base">Whatever cardigan tote bag tumblr hexagon
                        brooklyn asymmetrical gentrify, subway tile poke farm-to-table. Franzen you probably haven't
                        heard of them.</p>
                </div>
                <div class="flex flex-wrap -m-4">
                    <div class="p-4 lg:w-1/4 md:w-1/2">
                        <div class="h-full flex flex-col items-center text-center">
                            <img alt="team" class="flex-shrink-0 rounded-lg w-full h-56 object-cover object-center mb-4"
                                src="https://source.unsplash.com/random/4">
                            <div class="w-full">
                                <h2 class="title-font font-medium text-lg text-gray-900">Alper Kamu</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/4 md:w-1/2">
                        <div class="h-full flex flex-col items-center text-center">
                            <img alt="team" class="flex-shrink-0 rounded-lg w-full h-56 object-cover object-center mb-4"
                                src="https://source.unsplash.com/random/3">
                            <div class="w-full">
                                <h2 class="title-font font-medium text-lg text-gray-900">Holden Caulfield</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/4 md:w-1/2">
                        <div class="h-full flex flex-col items-center text-center">
                            <img alt="team" class="flex-shrink-0 rounded-lg w-full h-56 object-cover object-center mb-4"
                                src="https://source.unsplash.com/random/2">
                            <div class="w-full">
                                <h2 class="title-font font-medium text-lg text-gray-900">Atticus Finch</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                    <div class="p-4 lg:w-1/4 md:w-1/2">
                        <div class="h-full flex flex-col items-center text-center">
                            <img alt="team" class="flex-shrink-0 rounded-lg w-full h-56 object-cover object-center mb-4"
                                src="https://source.unsplash.com/random/1">
                            <div class="w-full">
                                <h2 class="title-font font-medium text-lg text-gray-900">Henry Letham</h2>
                                <h3 class="text-gray-700 mb-3">Jabatan</h3>
                                <h3 class="text-gray-700 mb-3">Prodi</h3>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- visi misi himip end -->
</body>

</html>