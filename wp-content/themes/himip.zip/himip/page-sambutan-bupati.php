<?php get_header(); ?>

    <div class="bg-blue-50 text-center py-20">
        <h2 class="title capitalize py-3">Kata Sambutan Bupati</h2>
    </div>
    <!-- visi misi himip -->
    <div class="container md:mx-auto py-10 flex flex-col">
        <div class="space-y-5 text-center md:text-left items-center justify-center flex flex-col">
            <!-- <p class="text-xl uppercase font-semibold text-blue-900">HIMIPCANDRADIMUKA</p> -->
            <h2 class="subtitle py-10 text-center">Sambutan Bupati HIMIP FISIP 2021/2022</h2>
            <div class=" p-5 prose prose-neutral bg-slate-100 rounded-md border-2 border-gray-300">
                <p class="text-slate-600 md:p-0 p-3 text-left">
                    Assalaamu’alaikum Warahmatullahi Wabarakatuh, <br>
                    Salam sejahtera bagi kita semua. <br>
                    Hidup mahasiswa!! <br>
                    Hidup rakyat Indonesia!! <br>
                    
                   
                </p>
                <p class="text-slate-600 md:p-0 p-3 text-justify">
                    
                    Selaras dengan perkembangan teknologi terkini yang mendukung perkembangan berbagai kegiatan yang salah
                    satunya media informasi. Melalui Dinas Komunikasi dan Informasi yang berkolaborasi dengan Dinas
                    Penelitian dan Pengembangan Himip Candradimuka mengembangkan media informasi berupa website yang diberi
                    nama Himipmedia.com yang nantinya ikut menyalurkan informasi aktual dikalangan mahasiswa.
                    Tim Himipmedia.com berupaya semaksimal mungkin dalam merangkum informasi beriringan bersama dengan
                    perkembangan kemajuan teknologi untuk memberikan hasil yang terbaik dan memberikan kepuasan kepada
                    pembaca.
                    Semoga dengan adanya Himipmedia.com bisa menjadikan wadah bagi mahasiswa Ilmu Pemerintahan untuk mencari
                    dan memberikan informasi serta menjadi wadah penyaluran minat dan bakat baik dalam bidang sosial maupun
                    politik.
                    <br>
                    Wassalaamu’alaikum Warahmatullahi Wabarakatuh,
                    <br>
                   
                </p>
                <p class="text-right w-full">
                    Tertanda,
                    <br>
                    Bupati Himip Fisip Unri Periode 2021/2022
                </p>
            </div>

        </div>
        <div class="w-full md:w-1/2 mx-auto py-5">
            <figcaption class="w-full flex items-center justify-center gap-3">
                <div class="w-32 h-32 rounded-full bg-cover" style="background-image: url('Bupati_Himip.jpg')"></div>
                <div class="">
                    <p class="font-bold text-xl">Rizal D. Hidayat</p>
                    <p class="">Bupati HIMIP Fisip Unri Periode 2021/2022</p>
                    <p>NIM. 1901110629
                    </p>
                </div>
            </figcaption>
        </div>
    </div>
    <!-- visi misi himip end -->

    </body>

</html>