<!-- Footer -->

        <footer class="body-font bg-slate-900 text-white">
            <div class="container px-5 py-8 mx-auto flex justify-between sm:flex-row flex-col">

                <p class="text-sm text-gray-500 sm:py-2 sm:mt-0 mt-4">©
                    2022 HIMIP Candradimuka | UNRI
                </p>
                <p class="text-sm text-gray-500 sm:py-2 sm:mt-0 mt-4">
                    <a href="https://beetcodestudio.github.io">Powered By BEETCODESTUDIO</a>
                </p>
            </div>
        </footer>
    </body>
</html>
<!-- Footer End -->